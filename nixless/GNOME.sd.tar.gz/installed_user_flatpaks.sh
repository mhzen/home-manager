flatpak install --user com.spotify.Client -y
flatpak install --user io.github.spacingbat3.webcord -y
flatpak install --user net.lutris.Lutris -y
